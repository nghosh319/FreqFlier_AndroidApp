Team Members:
Narayana Ghosh :      G01348658
Nandini Daggumalli :  G01354212
Vaishnavi Muddasani:  G01413018
Abhay Joshi:          G01394679      


JSP Links:

http://127.0.0.1:8080/frequentflier/login?user=Emily_Davis&pass=Emily@123

http://127.0.0.1:8080/frequentflier/Info.jsp?passid=32

http://127.0.0.1:8080/frequentflier/Flights.jsp?passid=12

http://127.0.0.1:8080/frequentflier/FlightDetails.jsp?flightid=4001

http://127.0.0.1:8080/frequentflier/AwardIds.jsp?passid=20

http://127.0.0.1:8080/frequentflier/RedemptionDetails.jsp?AwardId=201&passid=1

http://127.0.0.1:8080/frequentflier/GetPassengerids.jsp?passid=30

http://127.0.0.1:8080/frequentflier/TransferPoints.jsp?spid=1&dpid=2&npoints=5



Implementation:
1. Copy frequentflier file to webapps flder in tomcat server
2. Copy the file FreqFlier to AndroidStudioProjects folder where android studio is installed.
3. Run the android program to simulate and see the android pages.


The app can be tested by using below user and pass, though we have 40 users total in Databases in login table.
Preferred user to test is  Emily_Davis/Emily@123

User                 Pass
---------------------------
Emily_Davis	      Emily@123
Michael_Smith	Michael@123
Sarah_Johnson	Sarah@123
David_Brown	      David@123
Andrew_Taylor	Andrew@123
Elizabeth_Wilson	Elizabeth@123



